# Project Title

> High level description (2 sentences or less).

## Detailed Description

In-depth description of what the app does, and some implementation details.

## Infrastructure

List if we use Rabbit, MQ, Mongo, LDAP, etc.  Anything a docker secret would be needed for should be considered "infrastructure"

## Depends on the Following Other Applications

List the other __Thrivent__ applications that work with this app to achieve its goals
This could be domain projects, jar dependencies, other APIs, etc.

## (Optional) Example of how to use the service

You can put a URL here to access some data, or kick off some work.
Not needed for all apps.
