package com.thrivent.foundation.domain;

import static org.junit.Assert.assertEquals;

import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;

import com.thrivent.foundation.controllers.TestController;

@RunWith(JUnitPlatform.class)
public class TestStackTest {
	
	private Set<String> input;
	private TestStack ts;
	
	@Before
	public void setUp()
	{
		ts= new TestStack();
		input=new HashSet<String>();
	}
	
	@Test
	public void setWebUITest() {
		ts= new TestStack();
		input=new HashSet<String>();
		ts.setWebUI(input);
		assertEquals(input,ts.getWebUI());
	}
	@Test
	public void setSql() {
		ts= new TestStack();
		input=new HashSet<String>();
		ts.setSql(input);
		assertEquals(input,ts.getSql());
	}
	@Test
	public void setLanguageTest() {
		ts= new TestStack();
		ts.setLanguage("");
		assertEquals("",ts.getLanguage());
	}

}
