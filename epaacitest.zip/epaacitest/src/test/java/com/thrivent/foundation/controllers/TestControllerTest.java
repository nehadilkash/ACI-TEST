package com.thrivent.foundation.controllers;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

@RunWith(JUnitPlatform.class)
@WebMvcTest class TestControllerTest {
	
	@Autowired
	private MockMvc mockMvc;

	
	@SuppressWarnings("deprecation")
	@Test
	public void getEmployeesTest() throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
				"/employees/").accept(MediaType.ALL_VALUE);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		System.out.println(result.getResponse());
		//String expected = "welcome to First Program";
		assertEquals(200, result.getResponse().getStatus());
	}

	@Test
	public void createStudentCourse() throws Exception {
		
		

		// Send course as body to /students/Student1/courses
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/employees/")
				.accept(MediaType.APPLICATION_JSON).content("{}")
				.contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		MockHttpServletResponse response = result.getResponse();

		assertEquals(200, response.getStatus());

//		assertEquals("http://localhost/students/Student1/courses/1",
//				response.getHeader(HttpHeaders.LOCATION));

	}

}
