package com.thrivent.foundation;

import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;

@RunWith(JUnitPlatform.class)
@SpringBootTest(classes = SpringBootApplicationTests.class)
public class SpringBootApplicationTests {

	@Test
	public void contextLoads() {
	}

}
