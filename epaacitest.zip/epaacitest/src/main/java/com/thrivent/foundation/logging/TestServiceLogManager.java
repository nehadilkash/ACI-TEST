package com.thrivent.foundation.logging;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.thrivent.foundation.constants.TestConstants;
/**
 * @author Amar
 */
@SuppressWarnings("rawtypes")
public class TestServiceLogManager {


    private TestServiceLogManager() {
    }

    public static synchronized Logger getLogger( Class className) {
        return getLogger(className, null);
    }

    public static synchronized Logger getLogger( Class className, String logType) {
        Logger logger ;
        
        if(logType != null) {
        	logger = LogManager.getLogger(logType);
        } else {
        	logger = LogManager.getLogger(TestConstants.EPAAACI_LOGGER);
        }

        return logger;
    }

}
