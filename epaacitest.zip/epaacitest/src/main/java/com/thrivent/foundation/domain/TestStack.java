package com.thrivent.foundation.domain;
import java.util.Set;
import com.fasterxml.jackson.annotation.JsonInclude;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class TestStack {


	private Set<String> webUI;
	private Set<String> sql;
	private Set<String> noSql;
	private String language;
	private Set<String> security;

	public Set<String> getWebUI() {
		return webUI;
	}

	public void setWebUI(Set<String> webUI) {
		this.webUI = webUI;
	}

	public Set<String> getSql() {
		return sql;
	}

	public void setSql(Set<String> sql) {
		this.sql = sql;
	}

	public Set<String> getNoSql() {
		return noSql;
	}

	public void setNoSql(Set<String> noSql) {
		this.noSql = noSql;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String string) {
		this.language = string;
	}

	public Set<String> getSecurity() {
		return security;
	}

	public void setSecurity(Set<String> security) {
		this.security = security;
	}

	@Override
	public String toString() {
		return "TechnologyStack [webUI=" + webUI + ", sql=" + sql + ", noSql=" + noSql + ", language=" + language
				+ ", security=" + security + "]";
	}


}
