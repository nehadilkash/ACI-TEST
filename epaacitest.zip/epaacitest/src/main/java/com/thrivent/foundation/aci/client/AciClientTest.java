package com.thrivent.foundation.aci.client;

import org.springframework.stereotype.Component;

@Component
public class AciClientTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		AciClient aciClient = new AciClient();
		aciClient.getAddFunding(1);
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("Exceptoin occured"+e.toString());
		}
	}

}
