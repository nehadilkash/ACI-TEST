package com.thrivent.foundation.configuration;

import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
 
@Configuration
@PropertySource("file:${egress.proxy.auth}")
public class AppConfiguration {
    @Value("${egress.userid}")
    private String egressUserId;
    @Value("${egress.password}")
    private String egressPassword;
    @Value("${egress.proxy.url}")
    private String proxyUrl;
 
    @Bean
    public RestTemplate restTemplatePayment(RestTemplateBuilder builder) {
        return builder
            .build();
    }
 
    @Bean
    public RestTemplate restTemplateWithProxy(RestTemplateBuilder builder) {
        HttpHost proxy = HttpHost.create(proxyUrl);
 
        //Client credentials
        CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
        credentialsProvider.setCredentials(new AuthScope(proxy), new UsernamePasswordCredentials(egressUserId, egressPassword));
 
        // Create AuthCache instance
        AuthCache authCache = new BasicAuthCache();
         
        BasicScheme basicAuth = new BasicScheme();
        authCache.put(proxy, basicAuth);
 
        HttpClientContext context = HttpClientContext.create();
        context.setCredentialsProvider(credentialsProvider);
        context.setAuthCache(authCache);
 
        HttpClient httpClient = HttpClientBuilder.create()
            .setRoutePlanner(new DefaultProxyRoutePlanner(proxy))
            .setDefaultCredentialsProvider(credentialsProvider)
            .build();
 
        return builder
            .requestFactory(() -> new HttpComponentsClientHttpRequestFactory(httpClient))
            .build();
    }
}
