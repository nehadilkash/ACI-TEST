package com.thrivent.foundation;

import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.ComponentScan;
import com.thrivent.payments.epaapplicationbase.annotation.EPASpringBootApplication;

@EPASpringBootApplication
@ComponentScan(basePackages = "com.thrivent.foundation.*")
public class FoundationApplication {

	public static void main(String[] args) {
			SpringApplication.run(FoundationApplication.class, args);
	}
}
