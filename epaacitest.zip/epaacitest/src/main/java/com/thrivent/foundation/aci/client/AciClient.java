/**
 * 
 */
package com.thrivent.foundation.aci.client;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import com.thrivent.foundation.aci.jaxb.model.AddFundingRequest;
import com.thrivent.foundation.aci.jaxb.model.AddFundingResponse;
import com.thrivent.foundation.aci.jaxb.model.Identity;

/**
 * @author N075992
 *
 */
@Component
//@Bean(name = "restTemplateByPassSSL")
public class AciClient extends WebServiceGatewaySupport {
	@Autowired
	private RestTemplate restTemplateWithProxy;
	private static final int RETRY_COUNT = 2;
	RestTemplate restTemplate;
	
//	public AddFundingResponse getAddFunding(int id) {
//		AddFundingRequest addFundingRequest = new AddFundingRequest();
//		AddFundingResponse addFundingResponse = null;
//
//			Identity identity = new Identity();
//			identity.setBusinessId(504477);
//			identity.setLogin("CONNECTUSER");
//			identity.setPassword("Pass1word");
//			addFundingRequest.setIdentity(identity);
//			addFundingRequest.setProfileId("9503287");
//			addFundingRequest.setSuccessUrl("https://google.com/success");
//			addFundingRequest.setFailureUrl("https://google.com/failure");
//			addFundingRequest.setTimeOutUrl("https://google.com/timeout");
//			
//			 HttpHeaders headers = new HttpHeaders();
//		      headers.setAccept(Arrays.asList(MediaType.APPLICATION_ATOM_XML));
//		      HttpEntity<AddFundingRequest> entity = new HttpEntity<>(addFundingRequest,headers);
//		      
//		      return restTemplate.exchange(
//		         "https://collectpay-uat.princetonecom.com/fundingPortal/addFunding.do",
//		         HttpMethod.POST, entity, AddFundingResponse.class).getBody();
//		   
//	}

	public AddFundingResponse getAddFunding(int id) {
		AddFundingRequest addFundingRequest = new AddFundingRequest();
		AddFundingResponse addFundingResponse = null;

		try {
			Identity identity = new Identity();
			identity.setBusinessId(504477);
			identity.setLogin("CONNECTUSER");
			identity.setPassword("Pass1word");
			addFundingRequest.setIdentity(identity);
			addFundingRequest.setProfileId("9503287");
			addFundingRequest.setSuccessUrl("https://google.com/success");
			addFundingRequest.setFailureUrl("https://google.com/failure");
			addFundingRequest.setTimeOutUrl("https://google.com/timeout");
			/*
			 * System.out.println("AddFundingRequest=" + addFundingRequest);
			 * JAXB.marshal(addFundingRequest, System.out);
			 * 
			 * JAXBHelper jaxbHelper = new JAXBHelper(); Jaxb2Marshaller marshaller = new
			 * Jaxb2Marshaller(); marshaller.setClassesToBeBound(AddFundingRequest.class);
			 */
			JAXBContext jaxbContext = JAXBContext.newInstance(AddFundingRequest.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			jaxbMarshaller.marshal(addFundingRequest, System.out);

			Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
			marshaller.setPackagesToScan("com.thrivent.foundation.aci.jaxb.model");
			WebServiceTemplate webServiceTemplate = new WebServiceTemplate(marshaller);

			/*
			  SaajSoapMessageFactory messageFactory = new SaajSoapMessageFactory(
			  MessageFactory.newInstance()); messageFactory.afterPropertiesSet();
			  
			  WebServiceTemplate webServiceTemplate = new WebServiceTemplate(
			  messageFactory); Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
			  
			  marshaller.setContextPath("com.thrivent.payment.aci.jaxb.model");
			  marshaller.afterPropertiesSet();
			  
			  webServiceTemplate.setMarshaller(marshaller);
			  webServiceTemplate.afterPropertiesSet();
			 
			
			  addFundingResponse = (AddFundingResponse)
			  webServiceTemplate.marshalSendAndReceive(
			  "https://collectpay-uat.princetonecom.com/fundingPortal/addFunding.do",
			  addFundingRequest);
			 */
			addFundingResponse = (AddFundingResponse)
					  webServiceTemplate.marshalSendAndReceive(
					  "https://collectpay-uat.princetonecom.com/fundingPortal/addFunding.do",
					  addFundingRequest);
			// Start - SSL Proxy 

			/*HttpHeaders headers = new HttpHeaders();
			HttpEntity<AddFundingRequest> entity = new HttpEntity<AddFundingRequest>(addFundingRequest,headers);

			try {
				ResponseEntity<AddFundingResponse> response = restTemplateWithProxy.exchange(
						"https://collectpay-uat.princetonecom.com/fundingPortal/addFunding.do", HttpMethod.POST, entity,
						AddFundingResponse.class);
				System.out.println("-------response"+response);
				if (response == null) {
					System.out.println("testskk");
				}
				return response.getBody();
			} catch (RestClientException e) {
				System.out.println("exception" + e);
			}*/

			// End - SSL Proxy

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println("exception");
		}
		return addFundingResponse;
	}

	/*
	 * private ResponseEntity<String> callRestBasedAccuprice(HttpEntity<String>
	 * entity, HttpMethod httpMethod) throws Exception {
	 * 
	 * RetryTemplate retryTemplate = new RetryTemplate(); FixedBackOffPolicy
	 * backOffPolicy = new FixedBackOffPolicy();
	 * backOffPolicy.setBackOffPeriod(250);
	 * retryTemplate.setBackOffPolicy(backOffPolicy);
	 * 
	 * Map<Class<? extends Throwable>, Boolean> retryExceptions = new HashMap<>();
	 * retryExceptions.put(Exception.class, true);
	 * 
	 * SimpleRetryPolicy retryPolicy = new SimpleRetryPolicy(RETRY_COUNT,
	 * retryExceptions); retryTemplate.setRetryPolicy(retryPolicy);
	 * 
	 * ResponseEntity<String> response; try { response = restTemplate.exchange(
	 * "https://collectpay-uat.princetonecom.com/fundingPortal/addFunding.do",
	 * httpMethod, entity, String.class); } catch (Exception exp) { log.info(MESSAGE
	 * + ATTEMPT_NO + (retryContext.getRetryCount() + 1) + " FAILED " +
	 * FOR_SERVICE_URL + serviceProperties.getServiceUrl());
	 * 
	 * throw new ValidationException( "Exception while calling " + ATTEMPT_NO +
	 * (retryContext.getRetryCount() + 1) + " OF " +
	 * serviceProperties.getServiceUrl() + " Service ", exp, Constants.G_EMPTY_STR,
	 * serviceProperties.getServiceType());
	 * 
	 * } return response; }
	 */

}
