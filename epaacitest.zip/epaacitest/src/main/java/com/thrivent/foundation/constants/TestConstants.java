package com.thrivent.foundation.constants;

public class TestConstants {

	public static final String EPAAACI_LOGGER = "EpaAciLog";

}
