package com.thrivent.foundation.controllers;

import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.thrivent.foundation.aci.client.AciClient;
import com.thrivent.foundation.domain.TestStack;
import com.thrivent.foundation.logging.TestServiceLogManager;

@RestController
@RequestMapping("/employees")
public class TestController {
	
	
	private static final Logger LOGGER = TestServiceLogManager.getLogger(TestController.class);
	private static final HttpHeaders HTTP_RESPONSE_HEADERS = new HttpHeaders();
	
	@Autowired
	AciClient aciClient;
	
    @GetMapping(path="/", produces = "application/json")
    public String getEmployees() 
    {
    	aciClient.getAddFunding(1);
    	
        return "welcome to First Program";
    }

	
	@SuppressWarnings({ "rawtypes", "unchecked" })
    @PostMapping(path= "/", consumes = "application/json", produces = "application/json")
	@ResponseBody
	public ResponseEntity<TestStack> getRecommendationStack() throws Exception {
		TestStack testStack = new TestStack();

		try {
			testStack.setLanguage("Java Language");
			LOGGER.info("----------------Start--------------");
		} catch (Exception e) {
			LOGGER.error("Exception occured while getting TechnologyStack", e.getClass().getName(), e);

			return new ResponseEntity<>(testStack, HTTP_RESPONSE_HEADERS, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		LOGGER.info("----------------End Recommendation Engine-----------------");

		return new ResponseEntity<>(testStack, HTTP_RESPONSE_HEADERS, HttpStatus.OK);

	}

}
